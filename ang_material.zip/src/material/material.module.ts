import{ NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material';
import { MatButtonToggleModule, MatIconModule, MatBadgeModule } from '@angular/material';


const MaterialComponents = [
    MatButtonModule, MatButtonToggleModule, MatIconModule,MatBadgeModule
]

@NgModule({
    imports : [
MaterialComponents
    ],

    exports :[
MaterialComponents
    ]
})

export class MaterialModule
{
    
}